import userState from '../userState.js';
import eventBus from '../eventBus.js';
import api, { API_BASE_URL } from '../api.js';
import { showMessage } from '../utils.js';

const urlParams = new URLSearchParams(window.location.search);
const movieId = urlParams.get('id');

if (!movieId) {
    showMessage('电影ID不存在', 'error');
}

document.addEventListener('DOMContentLoaded', async () => {
    if (!movieId) {
        return;
    }

    await loadMovieDetail();

    const user = userState.getUser();

    if (user) {
        await fetch(`${API_BASE_URL}/api/movies/${movieId}/history?userId=${user.userId}&watchDuration=0`, {
            method: 'POST'
        }).catch(() => {});
    }

    await loadRecommendations(movieId, user ? user.userId : null);
    await loadComments(movieId);

    // 监听登录事件，登录后刷新页面状态
    eventBus.on('userLogin', async () => {
        await loadMovieDetail();
        await loadComments(movieId);
    });
});

async function loadMovieDetail() {
    const container = document.getElementById('movieDetail');
    container.innerHTML = '<div class="loading"><div class="spinner"></div><p>正在加载电影详情...</p></div>';

    try {
        const response = await api.getMovieDetail(movieId);
        if (response.code !== 1 || !response.data) {
            container.innerHTML = '<p class="empty-state">电影详情加载失败</p>';
            return;
        }

        const movie = response.data;
        const user = userState.getUser();
        container.innerHTML = `
            <div class="detail-poster">
              <img src="${movie.posterUrl || 'https://via.placeholder.com/300x450/1a1a2e/ffffff?text=电影海报'}" alt="${movie.title}">
            </div>
            <div class="detail-info">
              <h2>${movie.title}</h2>
              <div class="detail-meta">
                <p><strong>导演：</strong> ${movie.director || '未知'}</p>
                <p><strong>主演：</strong> ${movie.actors || '未知'}</p>
                <p><strong>类型：</strong> ${movie.genre || '未知'}</p>
                <p><strong>上映日期：</strong> ${movie.releaseDate || '未知'}</p>
                <p><strong>时长：</strong> ${movie.duration || '120'} 分钟</p>
                <p><strong>评分：</strong> ${movie.rating || '暂无'}</p>
              </div>
              <div class="detail-description">
                <h3>剧情介绍</h3>
                <p>${movie.description || '这是一部精彩的电影，敬请期待更多信息。'}</p>
              </div>
              <div class="btn-group">
                ${user ? `
                  <button class="btn" onclick="handleBuyTicket()">🎫 立即购票</button>
                  <button class="btn" onclick="handleToggleFavorite()" id="favoriteBtn" style="background: rgba(255,255,255,0.1);">❤️ 收藏</button>
                ` : `
                  <button class="btn" onclick="window.location.href='login.html'">🔐 登录购票</button>
                `}
              </div>
            </div>
        `;

        if (user) {
            await checkFavorite();
        }
    } catch (error) {
        console.error('加载电影详情失败:', error);
        container.innerHTML = '<p class="empty-state">网络异常，稍后重试</p>';
    }
}

async function checkFavorite() {
    const user = userState.getUser();
    if (!user) return;
    const token = userState.getToken();
    try {
        // Ensure we pass userId — backend expects it as request param
        const favorites = await api.getFavorites(token, user.userId);
        const btn = document.getElementById('favoriteBtn');
        if (!btn) return;

        // Normalize possible response shapes
        let favList = [];
        if (!favorites) favList = [];
        else if (Array.isArray(favorites)) favList = favorites; // legacy
        else if (favorites.data && Array.isArray(favorites.data.records)) favList = favorites.data.records;
        else if (favorites.data && Array.isArray(favorites.data)) favList = favorites.data;
        else if (favorites.records && Array.isArray(favorites.records)) favList = favorites.records;

        const found = favList.some(fav => String(fav.movieId) === String(movieId) || String(fav.id) === String(movieId) || String(fav.movie_id) === String(movieId));

        if (found) {
            btn.textContent = '✓ 已收藏';
            btn.dataset.isFavorite = 'true';
        } else {
            btn.textContent = '+ 收藏';
            btn.dataset.isFavorite = 'false';
        }
    } catch (error) {
        console.error('检查收藏状态失败:', error);
        // keep button in default state
        const btn = document.getElementById('favoriteBtn');
        if (btn) {
            btn.textContent = '+ 收藏';
            btn.dataset.isFavorite = 'false';
        }
    }
}

async function handleToggleFavorite() {
    if (!userState.isLoggedIn()) {
        showMessage('请先登录再收藏', 'error');
        setTimeout(() => {
            window.location.href = 'login.html';
        }, 1500);
        return;
    }

    const user = userState.getUser();
    const token = userState.getToken();
    const btn = document.getElementById('favoriteBtn');
    if (!btn) return;

    const isFavorite = btn.dataset.isFavorite === 'true';

    // disable button while processing
    btn.disabled = true;
    try {
        if (isFavorite) {
            const resp = await api.removeFavorite(token, movieId, user.userId);
            // accept multiple success shapes
            if (resp && (resp.code === 1 || resp.success === true || resp.status === 'ok')) {
                showMessage('取消收藏成功', 'success');
            } else {
                showMessage(resp?.msg || '取消收藏失败', 'error');
            }
        } else {
            const resp = await api.addFavorite(token, movieId, user.userId);
            if (resp && (resp.code === 1 || resp.success === true || resp.status === 'ok')) {
                showMessage('收藏成功', 'success');
            } else {
                showMessage(resp?.msg || '收藏失败', 'error');
            }
        }

        // refresh favorite status from server to keep consistent
        await checkFavorite();

    } catch (error) {
        console.error('收藏操作失败:', error);
        showMessage('收藏操作失败，请稍后再试', 'error');
    } finally {
        btn.disabled = false;
    }
}

function handleBuyTicket() {
    //showMessage('购票功能开发中...', 'success');
    // 检查电影ID
    if (!movieId) {
        showMessage('电影信息错误', 'error');
        return;
    }
    
    // 跳转到场次列表页面
    window.location.href = `movie-screenings.html?movieId=${movieId}`;
}

async function loadRecommendations(movieId, userId) {
    try {
        // backend provides a global recommend endpoint: GET /api/movies/recommend?limit=6
        const response = await api.getRecommendedMovies(6);
        if (response && response.code === 1 && response.data && Array.isArray(response.data.records)) {
            displayRecommendations(response.data.records);
        } else {
            console.warn('推荐接口返回格式不正确', response);
        }
    } catch (error) {
        console.error('加载推荐失败:', error);
    }
}

function displayRecommendations(movies) {
    const container = document.getElementById('recommendations');

    if (!container) {
        return;
    }

    if (movies.length === 0) {
        container.innerHTML = '<div class="empty-state">暂无推荐电影</div>';
        return;
    }

    container.innerHTML = movies.map(movie => `
        <div class="recommend-card" data-id="${movie.movieId || movie.id}">
            <div class="recommend-poster">
                <img src="${movie.posterUrl || 'https://via.placeholder.com/150x225/1a1a2e/ffffff?text=电影'}" 
                     alt="${movie.title}"
                     onerror="this.src='https://via.placeholder.com/150x225/1a1a2e/ffffff?text=电影'">
            </div>
            <div class="recommend-info">
                <h4 class="recommend-title">${movie.title}</h4>
                <p class="recommend-rating">⭐ ${movie.rating || 'N/A'}</p>
                <a href="movie-detail.html?id=${movie.movieId || movie.id}" class="recommend-link">详情</a>
            </div>
        </div>
    `).join('');
}

async function loadComments(movieId) {
    const listEl = document.getElementById('commentList');
    if (!listEl) return;

    listEl.innerHTML = '<p class="loading">正在加载评论...</p>';

    try {
        const response = await api.get(`/api/movies/${movieId}/comments`);
        if (response.code === 1 && Array.isArray(response.data)) {
            if (response.data.length === 0) {
                listEl.innerHTML = '<p class="empty-state">暂无评论，快来抢沙发！</p>';
                return;
            }

            listEl.innerHTML = response.data.map(comment => `
                <div class="comment-item">
                    <div class="comment-header">
                        <span class="comment-user">用户 ${comment.userId}</span>
                        <span class="comment-rating">${comment.rating ? `评分：${comment.rating}` : ''}</span>
                    </div>
                    <p class="comment-content">${comment.content}</p>
                    <span class="comment-time">${comment.createTime || ''}</span>
                </div>
            `).join('');
        } else {
            listEl.innerHTML = '<p class="empty-state">暂无评论</p>';
        }
    } catch (error) {
        console.error('加载评论失败:', error);
        listEl.innerHTML = '<p class="empty-state">加载评论失败</p>';
    }
}

async function handleSubmitComment() {
    // 检查登录状态
    if (!userState.isLoggedIn()) {
        showMessage('请先登录再发表评论', 'error');
        setTimeout(() => {
            window.location.href = 'login.html';
        }, 1500);
        return;
    }

    const user = userState.getUser();
    const contentInput = document.getElementById('commentContent');
    const ratingInput = document.getElementById('commentRating');
    const content = contentInput.value.trim();
    const rating = ratingInput.value;

    if (!content) {
        showMessage('评论内容不能为空', 'error');
        return;
    }

    try {
        const response = await api.post(`/api/movies/${movieId}/comments`, {
            userId: user.userId,
            content,
            rating: rating ? parseFloat(rating) : null
        });

        if (response.code === 1) {
            showMessage('评论成功！', 'success');
            contentInput.value = '';
            ratingInput.value = '';
            await loadComments(movieId);
        } else {
            showMessage(response.msg || '评论失败', 'error');
        }
    } catch (error) {
        console.error('提交评论失败:', error);
        showMessage('评论失败，请稍后再试', 'error');
    }
}

window.handleToggleFavorite = handleToggleFavorite;
window.handleBuyTicket = handleBuyTicket;
window.handleSubmitComment = handleSubmitComment;
