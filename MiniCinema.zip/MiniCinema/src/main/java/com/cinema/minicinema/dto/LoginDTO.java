package com.cinema.minicinema.dto;

import lombok.Data;

@Data
public class LoginDTO {
    private String username;  // 用户名
    private String password;  // 密码
}