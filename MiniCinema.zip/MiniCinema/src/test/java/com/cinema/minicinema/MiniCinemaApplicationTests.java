package com.cinema.minicinema;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniCinemaApplicationTests {

    @Test
    void contextLoads() {
    }

}
